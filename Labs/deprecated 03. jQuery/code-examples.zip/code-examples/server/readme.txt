
Cerinte sistem:
- Windows 7, Windows Vista SP1, Windows XP SP3
- .net 4.0

Configurare:
- se modifica daca este cazul parametrii Port si VirtualPath din fisierul HttpJsonServer.exe.config
- se modifica corespunzator adresa utilizata in fisierul Agenda_jQuery.html

Executie:
- se porneste aplicatia server (cu drepturi de administrator)
- se porneste aplicatia client (pagina HTML)