export class Paddle{
    x
    constructor(x){
        this.x = x;
    }
}