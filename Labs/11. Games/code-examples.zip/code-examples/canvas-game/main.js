import {Game} from './src/Game.js';
new Game();